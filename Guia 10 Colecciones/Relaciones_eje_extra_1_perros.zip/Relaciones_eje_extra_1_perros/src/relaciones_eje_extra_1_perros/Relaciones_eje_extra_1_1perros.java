/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package relaciones_eje_extra_1_perros;

import servicios.MenuPerros;

public class Relaciones_eje_extra_1_1perros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        MenuPerros mp = new MenuPerros();

        mp.mostrarMenu();

    }

}
